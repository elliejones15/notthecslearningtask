﻿'-------------------------------------------------
'- Coded By: Toby Watts             Version: 2.5 -
'- 'Caravan Park' Program       Date: 04/12/2021 -
'- This is an example answer for the 2018 Unit 2 -
'- paper for Computing AS.                       -
'-------------------------------------------------

'Importing stuff to located current directory to retrive the text
Imports System.IO
Public Class CaravanInput
    'declaring structure for customers details.
    Structure Customer
        Dim valTitleSTR As String
        Dim valNameSTR As String
        Dim valPaymentSTR As String
        Dim valPhoneSTR As String
        Dim valAddressSTR As String
        Dim valPostcodeSTR As String
    End Structure
    Dim Detail As Customer

    Private Sub btnstorecus_Click(sender As Object, e As EventArgs) Handles btnstorecus.Click
        'local variables for flags and validation
        Dim varFlagBOO As Boolean = False
        Dim varNumCheckBOO As Boolean
        Dim varRangeINT As Integer

        'gets length of text in textbox. used for range check later in code.
        varRangeINT = txtphone.TextLength

        'checks if there are numeric characters in name text box. used for type check.
        varNumCheckBOO = IsNumeric(txtname.Text)

        'presence check for textboxes
        If txtaddress.Text = "" Or txtname.Text = "" Or txtphone.Text = "" Or txtpost.Text = "" Then
            MsgBox("Please enter data into all fields.")
            'range check for phone number.
        ElseIf varRangeINT < 11 Or varRangeINT > 11 Then
            MsgBox("The phone number you have entered: " & txtphone.Text & " does not meet the 11 character requirement.")
            'type check for name field
        ElseIf varNumCheckBOO = True Then
            MsgBox("You have entered numeric characters into the name field.")
            'format check for post code.
        ElseIf txtpost.Text Like "[A-Z]" & "[A-Z]" & "[0-9]" & "[0-9]" & "[ ]" & "[0-9]" & "[A-Z]" & "[A-Z]" Then
            varFlagBOO = True
        End If

        'if the flag variable is true. then execute this code.
        If varFlagBOO = True Then
            'block of code to store data into record structure.
            Detail.valTitleSTR = cmbtitle.SelectedItem
            Detail.valNameSTR = txtname.Text
            Detail.valPaymentSTR = cmbpayment.SelectedItem
            Detail.valPhoneSTR = txtphone.Text
            Detail.valAddressSTR = txtaddress.Text
            Detail.valPostcodeSTR = txtpost.Text
            'code to write to textfile. REMEMBER TO USE APPEND. NOT OUTPUT.
            FileOpen(1, "Customer Details" + ".txt", OpenMode.Append)
            Print(1, "****************************")
            Print(1, vbNewLine)
            Print(1, "Title: " & Detail.valTitleSTR)
            Print(1, vbNewLine)
            Print(1, "Name: " & Detail.valNameSTR)
            Print(1, vbNewLine)
            Print(1, "Payment Method: " & Detail.valPaymentSTR)
            Print(1, vbNewLine)
            Print(1, "Phone: " & Detail.valPhoneSTR)
            Print(1, vbNewLine)
            Print(1, "Address: " & Detail.valAddressSTR)
            Print(1, vbNewLine)
            Print(1, "Postcode: " & Detail.valPostcodeSTR)
            Print(1, vbNewLine)
            Print(1, "****************************")
            FileClose(1)
            MsgBox("Operation Completed!")
        End If
    End Sub

    Private Sub btnget_Click(sender As Object, e As EventArgs) Handles btnget.Click
        'Grabs directory of .exe file.
        Dim FileDirectory As String = Directory.GetCurrentDirectory()
        Dim fileReader As String
        'loads the txt file. name is hardcoded as a user would have no reason to change it.
        fileReader = My.Computer.FileSystem.ReadAllText(FileDirectory + "\Customer Details.txt")
        'text is outputted to txtbox.
        txtoutput.Text = fileReader
    End Sub
End Class
