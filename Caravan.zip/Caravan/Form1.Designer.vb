﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CaravanInput
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CaravanInput))
        Me.btnget = New System.Windows.Forms.Button()
        Me.txtpost = New System.Windows.Forms.TextBox()
        Me.txtaddress = New System.Windows.Forms.TextBox()
        Me.txtphone = New System.Windows.Forms.TextBox()
        Me.cmbpayment = New System.Windows.Forms.ComboBox()
        Me.cmbtitle = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.btnstorecus = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblphone = New System.Windows.Forms.Label()
        Me.lblpayment = New System.Windows.Forms.Label()
        Me.lblname = New System.Windows.Forms.Label()
        Me.txtoutput = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnget
        '
        Me.btnget.Location = New System.Drawing.Point(97, 225)
        Me.btnget.Name = "btnget"
        Me.btnget.Size = New System.Drawing.Size(111, 37)
        Me.btnget.TabIndex = 28
        Me.btnget.Text = "Retrive Customer Details"
        Me.btnget.UseVisualStyleBackColor = True
        '
        'txtpost
        '
        Me.txtpost.Location = New System.Drawing.Point(108, 194)
        Me.txtpost.Name = "txtpost"
        Me.txtpost.Size = New System.Drawing.Size(100, 20)
        Me.txtpost.TabIndex = 27
        '
        'txtaddress
        '
        Me.txtaddress.Location = New System.Drawing.Point(98, 159)
        Me.txtaddress.Name = "txtaddress"
        Me.txtaddress.Size = New System.Drawing.Size(100, 20)
        Me.txtaddress.TabIndex = 26
        '
        'txtphone
        '
        Me.txtphone.Location = New System.Drawing.Point(155, 124)
        Me.txtphone.Name = "txtphone"
        Me.txtphone.Size = New System.Drawing.Size(100, 20)
        Me.txtphone.TabIndex = 25
        '
        'cmbpayment
        '
        Me.cmbpayment.FormattingEnabled = True
        Me.cmbpayment.Items.AddRange(New Object() {"Card", "PayPal", "Cash"})
        Me.cmbpayment.Location = New System.Drawing.Point(172, 89)
        Me.cmbpayment.Name = "cmbpayment"
        Me.cmbpayment.Size = New System.Drawing.Size(100, 21)
        Me.cmbpayment.TabIndex = 24
        '
        'cmbtitle
        '
        Me.cmbtitle.FormattingEnabled = True
        Me.cmbtitle.Items.AddRange(New Object() {"Mr", "Mrs", "Miss"})
        Me.cmbtitle.Location = New System.Drawing.Point(80, 22)
        Me.cmbtitle.Name = "cmbtitle"
        Me.cmbtitle.Size = New System.Drawing.Size(100, 21)
        Me.cmbtitle.TabIndex = 23
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(11, 21)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 22)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Title:"
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(80, 57)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(100, 20)
        Me.txtname.TabIndex = 21
        '
        'btnstorecus
        '
        Me.btnstorecus.Location = New System.Drawing.Point(15, 226)
        Me.btnstorecus.Name = "btnstorecus"
        Me.btnstorecus.Size = New System.Drawing.Size(75, 36)
        Me.btnstorecus.TabIndex = 20
        Me.btnstorecus.Text = "Store Details"
        Me.btnstorecus.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(11, 191)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(91, 22)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Postcode:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(11, 157)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 22)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "Address:"
        '
        'lblphone
        '
        Me.lblphone.AutoSize = True
        Me.lblphone.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblphone.Location = New System.Drawing.Point(11, 121)
        Me.lblphone.Name = "lblphone"
        Me.lblphone.Size = New System.Drawing.Size(138, 22)
        Me.lblphone.TabIndex = 17
        Me.lblphone.Text = "Phone Number:"
        '
        'lblpayment
        '
        Me.lblpayment.AutoSize = True
        Me.lblpayment.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpayment.Location = New System.Drawing.Point(11, 89)
        Me.lblpayment.Name = "lblpayment"
        Me.lblpayment.Size = New System.Drawing.Size(155, 22)
        Me.lblpayment.TabIndex = 16
        Me.lblpayment.Text = "Payment Method:"
        '
        'lblname
        '
        Me.lblname.AutoSize = True
        Me.lblname.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblname.Location = New System.Drawing.Point(11, 57)
        Me.lblname.Name = "lblname"
        Me.lblname.Size = New System.Drawing.Size(63, 22)
        Me.lblname.TabIndex = 15
        Me.lblname.Text = "Name:"
        '
        'txtoutput
        '
        Me.txtoutput.Location = New System.Drawing.Point(340, 12)
        Me.txtoutput.Multiline = True
        Me.txtoutput.Name = "txtoutput"
        Me.txtoutput.ReadOnly = True
        Me.txtoutput.Size = New System.Drawing.Size(231, 254)
        Me.txtoutput.TabIndex = 29
        '
        'CaravanInput
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(583, 278)
        Me.Controls.Add(Me.txtoutput)
        Me.Controls.Add(Me.btnget)
        Me.Controls.Add(Me.txtpost)
        Me.Controls.Add(Me.txtaddress)
        Me.Controls.Add(Me.txtphone)
        Me.Controls.Add(Me.cmbpayment)
        Me.Controls.Add(Me.cmbtitle)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.btnstorecus)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblphone)
        Me.Controls.Add(Me.lblpayment)
        Me.Controls.Add(Me.lblname)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "CaravanInput"
        Me.Text = "LlaethFarm Caravan Park Customer Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnget As Button
    Friend WithEvents txtpost As TextBox
    Friend WithEvents txtaddress As TextBox
    Friend WithEvents txtphone As TextBox
    Friend WithEvents cmbpayment As ComboBox
    Friend WithEvents cmbtitle As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtname As TextBox
    Friend WithEvents btnstorecus As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblphone As Label
    Friend WithEvents lblpayment As Label
    Friend WithEvents lblname As Label
    Friend WithEvents txtoutput As TextBox
End Class
