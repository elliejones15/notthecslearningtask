﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lblname = New System.Windows.Forms.Label()
        Me.lblpayment = New System.Windows.Forms.Label()
        Me.lblphone = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnstorecus = New System.Windows.Forms.Button()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbtitle = New System.Windows.Forms.ComboBox()
        Me.cmbpayment = New System.Windows.Forms.ComboBox()
        Me.txtphone = New System.Windows.Forms.TextBox()
        Me.txtaddress = New System.Windows.Forms.TextBox()
        Me.txtpost = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lstoutput = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'lblname
        '
        Me.lblname.AutoSize = True
        Me.lblname.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblname.Location = New System.Drawing.Point(12, 45)
        Me.lblname.Name = "lblname"
        Me.lblname.Size = New System.Drawing.Size(63, 22)
        Me.lblname.TabIndex = 0
        Me.lblname.Text = "Name:"
        '
        'lblpayment
        '
        Me.lblpayment.AutoSize = True
        Me.lblpayment.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpayment.Location = New System.Drawing.Point(12, 77)
        Me.lblpayment.Name = "lblpayment"
        Me.lblpayment.Size = New System.Drawing.Size(155, 22)
        Me.lblpayment.TabIndex = 1
        Me.lblpayment.Text = "Payment Method:"
        '
        'lblphone
        '
        Me.lblphone.AutoSize = True
        Me.lblphone.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblphone.Location = New System.Drawing.Point(12, 109)
        Me.lblphone.Name = "lblphone"
        Me.lblphone.Size = New System.Drawing.Size(138, 22)
        Me.lblphone.TabIndex = 2
        Me.lblphone.Text = "Phone Number:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 145)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 22)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Address:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 179)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(91, 22)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Postcode:"
        '
        'btnstorecus
        '
        Me.btnstorecus.Location = New System.Drawing.Point(16, 214)
        Me.btnstorecus.Name = "btnstorecus"
        Me.btnstorecus.Size = New System.Drawing.Size(75, 36)
        Me.btnstorecus.TabIndex = 5
        Me.btnstorecus.Text = "Store Details"
        Me.btnstorecus.UseVisualStyleBackColor = True
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(81, 45)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(100, 20)
        Me.txtname.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 22)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Title:"
        '
        'cmbtitle
        '
        Me.cmbtitle.FormattingEnabled = True
        Me.cmbtitle.Items.AddRange(New Object() {"Mr", "Mrs", "Miss"})
        Me.cmbtitle.Location = New System.Drawing.Point(81, 10)
        Me.cmbtitle.Name = "cmbtitle"
        Me.cmbtitle.Size = New System.Drawing.Size(100, 21)
        Me.cmbtitle.TabIndex = 8
        '
        'cmbpayment
        '
        Me.cmbpayment.FormattingEnabled = True
        Me.cmbpayment.Items.AddRange(New Object() {"Card", "PayPal", "Cash"})
        Me.cmbpayment.Location = New System.Drawing.Point(173, 77)
        Me.cmbpayment.Name = "cmbpayment"
        Me.cmbpayment.Size = New System.Drawing.Size(100, 21)
        Me.cmbpayment.TabIndex = 9
        '
        'txtphone
        '
        Me.txtphone.Location = New System.Drawing.Point(156, 112)
        Me.txtphone.Name = "txtphone"
        Me.txtphone.Size = New System.Drawing.Size(100, 20)
        Me.txtphone.TabIndex = 10
        '
        'txtaddress
        '
        Me.txtaddress.Location = New System.Drawing.Point(99, 147)
        Me.txtaddress.Name = "txtaddress"
        Me.txtaddress.Size = New System.Drawing.Size(100, 20)
        Me.txtaddress.TabIndex = 11
        '
        'txtpost
        '
        Me.txtpost.Location = New System.Drawing.Point(109, 182)
        Me.txtpost.Name = "txtpost"
        Me.txtpost.Size = New System.Drawing.Size(100, 20)
        Me.txtpost.TabIndex = 12
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(98, 213)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(111, 37)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "Retrive Customer Details"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lstoutput
        '
        Me.lstoutput.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstoutput.FormattingEnabled = True
        Me.lstoutput.ItemHeight = 20
        Me.lstoutput.Location = New System.Drawing.Point(297, 9)
        Me.lstoutput.Name = "lstoutput"
        Me.lstoutput.Size = New System.Drawing.Size(265, 244)
        Me.lstoutput.TabIndex = 14
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.ClientSize = New System.Drawing.Size(574, 263)
        Me.Controls.Add(Me.lstoutput)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtpost)
        Me.Controls.Add(Me.txtaddress)
        Me.Controls.Add(Me.txtphone)
        Me.Controls.Add(Me.cmbpayment)
        Me.Controls.Add(Me.cmbtitle)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.btnstorecus)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblphone)
        Me.Controls.Add(Me.lblpayment)
        Me.Controls.Add(Me.lblname)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Login"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblname As Label
    Friend WithEvents lblpayment As Label
    Friend WithEvents lblphone As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnstorecus As Button
    Friend WithEvents txtname As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents cmbtitle As ComboBox
    Friend WithEvents cmbpayment As ComboBox
    Friend WithEvents txtphone As TextBox
    Friend WithEvents txtaddress As TextBox
    Friend WithEvents txtpost As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents lstoutput As ListBox
End Class
