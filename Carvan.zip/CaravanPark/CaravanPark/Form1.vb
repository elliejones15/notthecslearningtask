﻿Public Class Form1
    Class CusDetails
        Public varNameSTR As String
        Public varTitleSTR As String
        Public varPaymentSTR As String
        Public varPhoneSTR As String
        Public varAddressSTR As String
        Public varPostcode As String
    End Class
    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstoutput.SelectedIndexChanged

        End Sub

        Private Sub btnstorecus_Click(sender As Object, e As EventArgs) Handles btnstorecus.Click

            If CusDetails.varPostcode Like "[0-9]" Then

            End If
        End Sub
    End Class
